
#!/bin/sh

# OB-USP-Agent deployment script
# OpenWrt 21.02 / aarch64 Cortex-A53

BUNDLE_DIR="$(cd "$(dirname "$0")" && pwd)"

IPK="$BUNDLE_DIR/obuspa_11.0.7-1_aarch64_cortex-a53.ipk"
INIT_TEMPLATE="$BUNDLE_DIR/init.d/obuspa"
DB_TEMPLATE="$BUNDLE_DIR/usp.db"

INIT="/etc/init.d/obuspa"
DB="/etc/obuspa/db/usp.db"
OBUSPA="/usr/sbin/obuspa"
CLI_SOCKET="/tmp/usp_cli"

BROKER_DEFAULT="10.1.3.133"

log()
{
    echo ""
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1"
}

error()
{
    echo ""
    echo "[ERROR] $1"
}

# --------------------------------------------------
# 1. Check root
# --------------------------------------------------

if [ "$(id -u)" != "0" ]; then
    error "Run this script as root."
    exit 1
fi

# --------------------------------------------------
# 2. Check deployment bundle
# --------------------------------------------------

log "Checking deployment bundle..."

[ -f "$IPK" ] || {
    error "IPK not found: $IPK"
    exit 1
}

[ -f "$INIT_TEMPLATE" ] || {
    error "Init script template not found."
    exit 1
}

[ -f "$DB_TEMPLATE" ] || {
    error "USP database template not found."
    exit 1
}

echo "[OK] IPK found"
echo "[OK] Init script found"
echo "[OK] Database template found"

# --------------------------------------------------
# 3. Get configuration
# --------------------------------------------------

echo ""
echo "======================================"
echo "       OB-USP-Agent Configuration"
echo "======================================"

printf "Enter Endpoint ID (012345-CHIMNAPUR7): "
read ENDPOINT_ID

# Format: 6 digits followed by hyphen and 12 alphanumeric characters
if ! echo "$ENDPOINT_ID" | grep -Eq '^[0-9]{6}-[A-Za-z0-9]{12}$'; then
    error "Invalid Endpoint ID."
    echo "Expected format: 6 digits-12 alphanumeric characters"
    echo "Example: 012345-CHIMNAPUR7"
    exit 1
fi

printf "Enter MQTT ClientID (example CHIMNAPUR7): "
read CLIENT_ID

# ClientID: 12 alphanumeric characters
if ! echo "$CLIENT_ID" | grep -Eq '^[A-Za-z0-9]{12}$'; then
    error "Invalid MQTT ClientID."
    echo "ClientID must contain exactly 12 alphanumeric characters."
    exit 1
fi

printf "Enter MQTT Broker IP [%s]: " "$BROKER_DEFAULT"
read BROKER_IP

[ -z "$BROKER_IP" ] && BROKER_IP="$BROKER_DEFAULT"

echo ""
echo "Configuration:"
echo "Endpoint ID : $ENDPOINT_ID"
echo "Client ID   : $CLIENT_ID"
echo "Broker IP   : $BROKER_IP"

printf "Continue? (y/n): "
read CONFIRM

case "$CONFIRM" in
    y|Y|yes|YES)
        ;;
    *)
        echo "Installation cancelled."
        exit 0
        ;;
esac

# --------------------------------------------------
# 4. OPKG update
# --------------------------------------------------

log "Running opkg update..."

OPKG_LOG="/tmp/obuspa_opkg_update.log"

opkg update > "$OPKG_LOG" 2>&1
OPKG_RC=$?

cat "$OPKG_LOG"

SUCCESS_COUNT="$(grep -c 'Updated list of available packages in' "$OPKG_LOG")"

if [ "$SUCCESS_COUNT" -gt 0 ]; then
    echo "[OK] $SUCCESS_COUNT package feed(s) updated."

    if [ "$OPKG_RC" -ne 0 ]; then
        echo "[WARNING] Some feeds failed. Continuing with available package lists."
    fi
else
    error "No package feeds updated successfully."
    exit 1
fi

# --------------------------------------------------
# 5. Check existing database
# --------------------------------------------------

DB_EXISTED=0

if [ -f "$DB" ]; then
    DB_EXISTED=1
fi

# --------------------------------------------------
# 6. Backup existing files
# --------------------------------------------------

BACKUP_SUFFIX="$(date '+%Y%m%d_%H%M%S')"

if [ -f "$INIT" ]; then
    cp -p "$INIT" "$INIT.backup_$BACKUP_SUFFIX"
    echo "[OK] Existing init script backed up."
fi

if [ -f "$DB" ]; then
    cp -p "$DB" "$DB.backup_$BACKUP_SUFFIX"
    echo "[OK] Existing database backed up."
fi

# --------------------------------------------------
# 7. Install OB-USP-Agent
# --------------------------------------------------

log "Installing OB-USP-Agent..."

if opkg install "$IPK"; then
    echo "[OK] OB-USP-Agent installation successful."
else
    echo "[WARNING] Normal installation failed."
    echo "[INFO] Trying force reinstall..."

    if opkg install --force-reinstall "$IPK"; then
        echo "[OK] Force reinstall successful."
    else
        error "OB-USP-Agent installation failed."
        exit 1
    fi
fi

# --------------------------------------------------
# 8. Install database on first installation
# --------------------------------------------------

mkdir -p /etc/obuspa/db

if [ "$DB_EXISTED" -eq 0 ]; then
    cp "$DB_TEMPLATE" "$DB" || {
        error "Failed to install database."
        exit 1
    }
    echo "[OK] New USP database installed."
else
    echo "[INFO] Existing database preserved."
fi

# --------------------------------------------------
# 9. Install init script and update Endpoint ID
# --------------------------------------------------

log "Installing init script..."

cp "$INIT_TEMPLATE" "$INIT" || {
    error "Failed to copy init script."
    exit 1
}

# Replace existing Endpoint ID with new Endpoint ID
if grep -Eq '[0-9]{6}-[A-Za-z0-9]{12}' "$INIT"; then
    sed -i "s/[0-9][0-9][0-9][0-9][0-9][0-9]-[A-Za-z0-9][A-Za-z0-9][A-Za-z0-9][A-Za-z0-9][A-Za-z0-9][A-Za-z0-9][A-Za-z0-9][A-Za-z0-9][A-Za-z0-9][A-Za-z0-9][A-Za-z0-9][A-Za-z0-9]/$ENDPOINT_ID/g" "$INIT"
else
    error "Endpoint ID pattern not found in init script."
    exit 1
fi

chmod +x "$INIT"

echo "[OK] Init script installed."
echo "[OK] Endpoint ID updated."

# --------------------------------------------------
# 10. Enable service
# --------------------------------------------------

log "Enabling OB-USP-Agent..."

"$INIT" enable || {
    error "Unable to enable OB-USP-Agent."
    exit 1
}

echo "[OK] Agent enabled."

# --------------------------------------------------
# 11. Start agent BEFORE CLI configuration
# --------------------------------------------------

log "Starting OB-USP-Agent..."

"$INIT" start || {
    error "Unable to start OB-USP-Agent."
    exit 1
}

log "Waiting for OB-USP-Agent CLI socket..."

COUNT=0

while [ "$COUNT" -lt 20 ]; do
    if [ -S "$CLI_SOCKET" ] || [ -e "$CLI_SOCKET" ]; then
        break
    fi

    sleep 1
    COUNT=$((COUNT + 1))
done

if [ ! -e "$CLI_SOCKET" ]; then
    error "USP CLI socket was not created."
    "$INIT" status
    exit 1
fi

if ! pidof obuspa >/dev/null 2>&1; then
    error "OB-USP-Agent process is not running."
    exit 1
fi

echo "[OK] OB-USP-Agent is running."
echo "[OK] CLI socket is available."

# --------------------------------------------------
# 12. Configure MQTT parameters
# --------------------------------------------------

log "Configuring MQTT parameters..."

"$OBUSPA" -c set Device.MQTT.Client.1.ClientID "$CLIENT_ID"

if [ $? -ne 0 ]; then
    error "Failed to configure MQTT ClientID."
    exit 1
fi

"$OBUSPA" -c set Device.MQTT.Client.1.BrokerAddress "$BROKER_IP"

if [ $? -ne 0 ]; then
    error "Failed to configure MQTT BrokerAddress."
    exit 1
fi

echo "[OK] MQTT parameters configured."

# --------------------------------------------------
# 13. Verify MQTT configuration
# --------------------------------------------------

log "Verifying MQTT configuration..."

CLIENT_RESULT="$("$OBUSPA" -c get Device.MQTT.Client.1.ClientID 2>&1)"
BROKER_RESULT="$("$OBUSPA" -c get Device.MQTT.Client.1.BrokerAddress 2>&1)"

echo "$CLIENT_RESULT"
echo "$BROKER_RESULT"

echo "$CLIENT_RESULT" | grep -F "$CLIENT_ID" >/dev/null || {
    error "ClientID verification failed."
    exit 1
}

echo "$BROKER_RESULT" | grep -F "$BROKER_IP" >/dev/null || {
    error "BrokerAddress verification failed."
    exit 1
}

echo "[OK] MQTT configuration verified."

# --------------------------------------------------
# 14. Restart agent
# --------------------------------------------------

log "Restarting OB-USP-Agent..."

"$INIT" restart || {
    error "Agent restart failed."
    exit 1
}

# --------------------------------------------------
# 15. Verify agent after restart
# --------------------------------------------------

log "Checking agent after restart..."

sleep 3

if pidof obuspa >/dev/null 2>&1; then
    echo "[OK] OB-USP-Agent process is running."
else
    error "OB-USP-Agent is not running after restart."
    "$INIT" status
    exit 1
fi

"$INIT" status

# --------------------------------------------------
# 16. Final summary
# --------------------------------------------------

echo ""
echo "======================================"
echo "       DEPLOYMENT COMPLETED"
echo "======================================"
echo "Endpoint ID : $ENDPOINT_ID"
echo "Client ID   : $CLIENT_ID"
echo "Broker IP   : $BROKER_IP"
echo "Agent       : Running"
echo "Service     : Enabled"
echo "======================================"

